// Basile Pesin
// http://vertmo.github.io

// MetaBalls : p5.js implementation

class Blob {

    constructor(x, y, r) {
      this.x = x;
      this.y = y;
      let angle = random(0, 2 * PI);
      this.xspeed = random(1,4) * Math.cos(angle);
      this.yspeed = random(1,4) * Math.sin(angle);
      this.r = r;
    }
  
    update() {
      this.x += this.xspeed;
      this.y += this.yspeed;
      if (this.x > width || this.x < 0) {
        this.xspeed *= -1;
      }
      if (this.y > height || this.y < 0) {
        this.yspeed *= -1;
      }
    }
  
    show() {
      noFill();
      stroke(0);
      strokeWeight(4);
      ellipse(this.x, this.y, this.r * 2, this.r * 2);
    }
  }